import React, { useState, useEffect } from 'react';
import { Building, Language } from '../types';
import { CONIC_INFO } from '../data/translations';
import { getCompareState, addToCompare, removeFromCompare } from '../utils/compareStorage';
import { useAuth } from '../context/AuthContext';
import { MapPin, Calendar, Eye, Scale, Check, Heart, User } from 'lucide-react';
import { HighlightText } from './HighlightText';

interface BuildingCardProps {
  building: Building;
  lang: Language;
  searchQuery?: string;
  onOpenDetails: (building: Building) => void;
  onOpenCompare?: () => void;
}

export const BuildingCard: React.FC<BuildingCardProps> = ({
  building,
  lang,
  searchQuery,
  onOpenDetails,
  onOpenCompare,
}) => {
  const conic = CONIC_INFO[building.conicType];
  const [compareState, setCompareState] = useState(() => getCompareState());
  const { isFavorited, toggleFavorite } = useAuth();
  const favorited = isFavorited(building.id);

  useEffect(() => {
    const handleUpdate = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      setCompareState(detail || getCompareState());
    };
    window.addEventListener('conic_compare_change', handleUpdate);
    return () => window.removeEventListener('conic_compare_change', handleUpdate);
  }, []);

  const isSelectedA = compareState.idA === building.id;
  const isSelectedB = compareState.idB === building.id;
  const isSelected = isSelectedA || isSelectedB;

  const isSearchMatch = Boolean(
    searchQuery &&
      searchQuery.trim() &&
      (building.nameEn.toLowerCase().includes(searchQuery.toLowerCase().trim()) ||
        building.nameHi.toLowerCase().includes(searchQuery.toLowerCase().trim()) ||
        building.city.toLowerCase().includes(searchQuery.toLowerCase().trim()) ||
        building.country.toLowerCase().includes(searchQuery.toLowerCase().trim()) ||
        building.architect.toLowerCase().includes(searchQuery.toLowerCase().trim()))
  );

  const handleCompareClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isSelected) {
      removeFromCompare(building.id);
    } else {
      const { isComplete } = addToCompare(building.id);
      if (isComplete && onOpenCompare) {
        onOpenCompare();
      }
    }
  };

  return (
    <div
      id={`building-card-${building.id}`}
      className={`group relative bg-[#1a1a1a] hover:bg-[#202424] border rounded-2xl p-5 transition-all duration-300 ease-out flex flex-col justify-between shadow-md hover:shadow-xl backdrop-blur-sm ${
        isSelected
          ? 'border-[#B6FFED] ring-1 ring-[#B6FFED]/50 shadow-lg shadow-[#B6FFED]/15'
          : isSearchMatch
          ? 'border-[#B6FFED] ring-1 ring-[#B6FFED]/40 shadow-lg shadow-[#B6FFED]/15'
          : 'border-[#333333] hover:border-[#B6FFED]/40'
      }`}
    >
      <div>
        {/* Top Badges */}
        <div className="flex items-center justify-between gap-2 mb-3">
          <span className={`text-[11px] px-2.5 py-1 rounded-full font-bold border ${conic.badgeBg}`}>
            {conic.symbol} {lang === 'en' ? conic.nameEn : conic.nameHi}
          </span>
          <div className="flex items-center gap-1.5">
            <button
              id={`fav-btn-${building.id}`}
              onClick={(e) => {
                e.stopPropagation();
                toggleFavorite(building.id, building.conicType);
              }}
              className={`p-1 rounded-lg transition-all ${
                favorited
                  ? 'text-rose-400 bg-rose-500/20 border border-rose-500/30 shadow-sm'
                  : 'text-slate-400 hover:text-rose-300 hover:bg-slate-800 border border-transparent'
              }`}
              title={
                favorited
                  ? lang === 'en'
                    ? 'Saved in Firebase. Click to remove.'
                    : 'फायरबेस में सहेजा गया। हटाने के लिए क्लिक करें।'
                  : lang === 'en'
                  ? 'Bookmark structure to Firebase account'
                    : 'फायरबेस खाते में सहेजें'
              }
            >
              <Heart className={`w-3.5 h-3.5 ${favorited ? 'fill-current' : ''}`} />
            </button>
            <a
              id={`card-wiki-link-${building.id}`}
              href={`https://en.wikipedia.org/wiki/${building.wikipediaId}`}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors flex items-center justify-center border border-transparent hover:border-slate-700"
              title={lang === 'en' ? `Read on Wikipedia: ${building.nameEn}` : `विकिपीडिया पर पढ़ें: ${building.nameHi}`}
            >
              <span className="w-3.5 h-3.5 rounded bg-slate-200 text-slate-900 flex items-center justify-center font-serif font-black text-[9px] leading-none">
                W
              </span>
            </a>
            {isSelected && (
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#B6FFED]/15 text-[#B6FFED] font-bold border border-[#B6FFED]/40 flex items-center gap-1">
                <Check className="w-3 h-3" />
                <span>{isSelectedA ? 'Structure A' : 'Structure B'}</span>
              </span>
            )}
            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-[#B6FFED] font-semibold">
              e = {building.eccentricity.toFixed(3)}
            </span>
          </div>
        </div>

        {/* Building Title */}
        <h3 className="text-lg font-bold text-white group-hover:text-[#B6FFED] transition-colors tracking-tight font-display mb-1">
          <HighlightText
            text={lang === 'en' ? building.nameEn : building.nameHi}
            query={searchQuery}
          />
        </h3>

        {/* Secondary Title (other language) */}
        <p className="text-xs text-slate-400 font-sans mb-3">
          <HighlightText
            text={lang === 'en' ? building.nameHi : building.nameEn}
            query={searchQuery}
          />
        </p>

        {/* Mathematical Equation Pill */}
        <div className="bg-slate-950/80 border border-slate-800/90 group-hover:border-[#B6FFED]/20 rounded-lg p-2.5 mb-3.5 font-mono text-xs text-slate-300 transition-colors">
          <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-0.5">
            {lang === 'en' ? 'Equation' : 'समीकरण'}
          </div>
          <div className="text-[#B6FFED] font-semibold truncate" title={building.realWorldEquation}>
            {building.realWorldEquation}
          </div>
        </div>

        {/* Structural Summary */}
        <p className="text-xs text-slate-300 line-clamp-3 leading-relaxed mb-4">
          {lang === 'en' ? building.architecturalAdvantageEn : building.architecturalAdvantageHi}
        </p>
      </div>

      {/* Metadata & Action Footer */}
      <div>
        <div className="space-y-1.5 text-[11px] text-slate-400 border-t border-slate-800/80 pt-3 mb-3 font-sans">
          {/* Architect Row */}
          <div className="flex items-center gap-1.5 truncate">
            <User className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            <span className="truncate">
              <span className="text-slate-500 text-[10px] uppercase font-semibold mr-1">
                {lang === 'en' ? 'Architect:' : 'वास्तुकार:'}
              </span>
              <span className="text-slate-300">
                <HighlightText text={building.architect} query={searchQuery} />
              </span>
            </span>
          </div>

          {/* City, Country & Year Built */}
          <div className="grid grid-cols-2 gap-2">
            <div className="flex items-center gap-1.5 truncate">
              <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <span className="truncate">
                <span className="text-slate-300">
                  <HighlightText text={building.city} query={searchQuery} />
                </span>
                , {building.country}
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <span>{building.yearBuilt}</span>
            </div>
          </div>
        </div>

        {/* Action Buttons: Inspect & Compare */}
        <div className="grid grid-cols-2 gap-2">
          <button
            id={`view-details-${building.id}`}
            onClick={() => onOpenDetails(building)}
            className="py-2 px-2.5 rounded-xl text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-slate-200 hover:text-[#B6FFED] transition-all duration-200 flex items-center justify-center gap-1 border border-slate-700/70 hover:border-[#B6FFED]/40"
            title={lang === 'en' ? 'Inspect 3D interactive model & engineering dossier' : '3D मॉडल व डोजियर देखें'}
          >
            <Eye className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">{lang === 'en' ? '3D Dossier' : '3D डोजियर'}</span>
          </button>

          <button
            id={`compare-btn-${building.id}`}
            onClick={handleCompareClick}
            className={`py-2 px-2.5 rounded-xl text-xs font-bold transition-all duration-200 flex items-center justify-center gap-1 border ${
              isSelected
                ? 'bg-[#B6FFED] border-[#B6FFED] text-[#0a0a0a] shadow-lg shadow-[#B6FFED]/25'
                : 'bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white border-slate-700 hover:border-[#B6FFED]/50'
            }`}
            title={
              isSelected
                ? lang === 'en'
                  ? 'Selected for comparison. Click to deselect.'
                  : 'तुलना के लिए चयनित। हटाने के लिए क्लिक करें।'
                : lang === 'en'
                ? 'Add to side-by-side comparison (auto-opens when 2 selected)'
                : 'तुलना में जोड़ें'
            }
          >
            <Scale className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">
              {isSelected
                ? lang === 'en'
                  ? 'Selected'
                  : 'चयनित'
                : lang === 'en'
                ? 'Compare'
                : 'तुलना'}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};

