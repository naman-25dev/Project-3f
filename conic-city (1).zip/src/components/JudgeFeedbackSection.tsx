import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Language } from '../types';
import { submitFeedback, subscribeFeedback, JudgeFeedbackItem } from '../services/firebaseService';
import { Star, MessageSquare, Send, CheckCircle2, User, Sparkles, ShieldCheck } from 'lucide-react';

interface JudgeFeedbackSectionProps {
  lang: Language;
}

export const JudgeFeedbackSection: React.FC<JudgeFeedbackSectionProps> = ({ lang }) => {
  const { user, signInWithGoogle, signInAsGuest } = useAuth();
  const [rating, setRating] = useState<number>(5);
  const [comment, setComment] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submitted, setSubmitted] = useState<boolean>(false);
  const [feedbackList, setFeedbackList] = useState<JudgeFeedbackItem[]>([]);

  useEffect(() => {
    const unsubscribe = subscribeFeedback((list) => {
      setFeedbackList(list);
    });
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!comment.trim()) return;

    let activeUser = user;
    if (!activeUser) {
      await signInWithGoogle();
      return;
    }

    setIsSubmitting(true);
    try {
      await submitFeedback(
        activeUser.uid,
        activeUser.displayName || (activeUser.isAnonymous ? (lang === 'en' ? 'Guest Judge' : 'अतिथि जज') : 'Evaluation Judge'),
        rating,
        comment.trim()
      );
      setComment('');
      setSubmitted(true);
      setTimeout(() => setSubmitted(false), 4000);
    } catch (err) {
      console.warn('Feedback submission notice:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="w-full bg-[#1a1a1a] border border-[#333333] rounded-2xl p-4 md:p-6 shadow-xl backdrop-blur-md">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6 pb-4 border-b border-[#333333]">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-sky-500/20 text-sky-400">
              <MessageSquare className="w-5 h-5" />
            </span>
            <h3 className="text-xl font-bold tracking-tight text-white font-display">
              {lang === 'en' ? 'Judge Evaluation & Mathematical Feedback' : 'जज मूल्यांकन व गणितीय समीक्षा'}
            </h3>
          </div>
          <p className="text-xs md:text-sm text-slate-400 mt-1 max-w-2xl">
            {lang === 'en'
              ? 'Submit live assessment notes, rigor evaluations, and comments stored in cloud Firestore.'
              : 'लाइव मूल्यांकन नोट्स, गणितीय सटीकता समीक्षा फायरस्टोर में दर्ज करें।'}
          </p>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-sky-400 bg-sky-950/60 border border-sky-800/60 px-3 py-1.5 rounded-xl font-mono self-start sm:self-auto">
          <Sparkles className="w-3.5 h-3.5" />
          <span>{lang === 'en' ? 'Live Cloud Storage' : 'लाइव क्लाउड स्टोरेज'}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Feedback Input Form */}
        <div className="lg:col-span-5 bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 sm:p-5 flex flex-col justify-between">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                {lang === 'en' ? 'Architectural Rigor Rating' : 'गणितीय व वास्तुशिल्प रेटिंग'}
              </label>
              <div className="flex items-center gap-1.5">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    className="p-1 text-slate-600 hover:text-amber-400 transition-colors"
                  >
                    <Star
                      className={`w-6 h-6 ${
                        star <= rating
                          ? 'text-amber-400 fill-amber-400'
                          : 'text-slate-700'
                      }`}
                    />
                  </button>
                ))}
                <span className="text-xs font-mono font-bold text-amber-300 ml-2">
                  {rating} / 5
                </span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                {lang === 'en' ? 'Evaluation Notes & Remarks' : 'समीक्षा व टिप्पणियां'}
              </label>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder={
                  lang === 'en'
                    ? 'Enter remarks on eccentricity proofs, acoustic wave simulations, or 3D geometry accuracy...'
                    : 'उत्केंद्रता गणना, ध्वनिकी तरंग सिमुलेशन या 3D ज्यामिति सटीकता पर टिप्पणी दर्ज करें...'
                }
                rows={4}
                maxLength={1000}
                required
                className="w-full bg-slate-900 border border-slate-700/80 rounded-xl p-3 text-xs sm:text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-sky-500 transition-colors resize-none"
              />
              <div className="flex justify-between items-center text-[10px] text-slate-500 font-mono mt-1">
                <span>{lang === 'en' ? 'Stored securely in Firestore' : 'फायरस्टोर में सुरक्षित'}</span>
                <span>{comment.length} / 1000</span>
              </div>
            </div>

            {submitted && (
              <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-800 text-xs text-emerald-300 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  {lang === 'en'
                    ? 'Evaluation published to live exhibition board!'
                    : 'समीक्षा लाइव बोर्ड पर दर्ज कर दी गई है!'}
                </span>
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting || !comment.trim()}
              className="w-full py-2.5 px-4 rounded-xl text-xs sm:text-sm font-semibold bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-500 hover:to-indigo-500 disabled:opacity-50 text-white transition-all flex items-center justify-center gap-2 shadow-lg shadow-sky-600/20"
            >
              {isSubmitting ? (
                <span>{lang === 'en' ? 'Recording...' : 'दर्ज हो रहा है...'}</span>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>
                    {user
                      ? lang === 'en'
                        ? 'Publish Evaluation'
                        : 'समीक्षा पोस्ट करें'
                      : lang === 'en'
                      ? 'Sign in with Google & Publish'
                      : 'गूगल से साइन इन करें व पोस्ट करें'}
                  </span>
                </>
              )}
            </button>

            {!user && (
              <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 pt-0.5">
                <span>{lang === 'en' ? 'No Google account?' : 'गूगल खाता नहीं है?'}</span>
                <button
                  type="button"
                  onClick={signInAsGuest}
                  className="text-sky-400 hover:text-sky-300 underline font-medium"
                >
                  {lang === 'en' ? 'Continue as Guest Judge' : 'अतिथि जज के रूप में पोस्ट करें'}
                </button>
              </div>
            )}
          </form>
        </div>

        {/* Live Feedback Feed */}
        <div className="lg:col-span-7 space-y-3">
          <div className="flex items-center justify-between mb-1">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-sky-400" />
              <span>{lang === 'en' ? 'Recent Judge Submissions' : 'हालिया जज समीक्षाएं'}</span>
            </h4>
            <span className="text-xs font-mono text-slate-500">
              {feedbackList.length} {lang === 'en' ? 'records' : 'प्रविष्टियां'}
            </span>
          </div>

          {feedbackList.length === 0 ? (
            <div className="p-8 text-center rounded-xl bg-slate-950/60 border border-slate-800/80 text-slate-500 text-xs">
              {lang === 'en'
                ? 'No evaluations submitted yet. Be the first judge to leave architectural feedback!'
                : 'अभी तक कोई समीक्षा नहीं। पहली समीक्षा आप दर्ज करें!'}
            </div>
          ) : (
            <div className="space-y-2.5 max-h-[360px] overflow-y-auto pr-1">
              {feedbackList.map((item) => (
                <div
                  key={item.id}
                  className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/80 hover:border-slate-700 transition-all text-xs"
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 rounded-md bg-sky-950 border border-sky-800 text-sky-400 flex items-center justify-center text-[10px] font-bold">
                        <User className="w-3 h-3" />
                      </div>
                      <span className="font-semibold text-slate-200">
                        {item.userName}
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={`w-3 h-3 ${
                            i < item.rating
                              ? 'text-amber-400 fill-amber-400'
                              : 'text-slate-800'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  <p className="text-slate-300 leading-relaxed font-sans">
                    {item.comment}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
