import React, { useState, useEffect } from 'react';
import { Language } from '../types';
import { BUILDINGS_DATA } from '../data/buildings';
import { getCompareState, clearCompare } from '../utils/compareStorage';
import { Scale, X, ArrowRight } from 'lucide-react';

interface CompareFloatingBarProps {
  lang: Language;
  onOpenCompare: () => void;
}

export const CompareFloatingBar: React.FC<CompareFloatingBarProps> = ({ lang, onOpenCompare }) => {
  const [compareState, setCompareState] = useState(() => getCompareState());

  useEffect(() => {
    const handleUpdate = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      setCompareState(detail || getCompareState());
    };
    window.addEventListener('conic_compare_change', handleUpdate);
    return () => window.removeEventListener('conic_compare_change', handleUpdate);
  }, []);

  // If nothing selected or both selected (auto-opened), no floating banner needed unless 1 is selected
  const hasOne = compareState.idA && !compareState.idB;
  const hasBoth = compareState.idA && compareState.idB;

  if (!hasOne && !hasBoth) return null;

  const bA = BUILDINGS_DATA.find((b) => b.id === compareState.idA);
  const bB = BUILDINGS_DATA.find((b) => b.id === compareState.idB);

  return (
    <div className="fixed bottom-4 left-4 right-4 sm:left-auto sm:right-6 z-50 max-w-lg w-full animate-bounce-short">
      <div className="bg-[#0e1112]/95 border border-[#B6FFED]/50 rounded-2xl p-3.5 sm:p-4 shadow-[0_16px_36px_rgba(0,0,0,0.7),0_0_24px_rgba(182,255,237,0.15)] backdrop-blur-xl flex items-center justify-between gap-3 text-slate-100">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-[#B6FFED]/15 border border-[#B6FFED]/40 flex items-center justify-center text-[#B6FFED] shrink-0 shadow-[0_0_10px_rgba(182,255,237,0.2)]">
            <Scale className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <div className="text-xs font-bold text-white flex items-center gap-1.5 truncate">
              <span className="text-[#B6FFED] font-mono">
                {hasBoth ? '2/2 Selected' : '1/2 Selected'}:
              </span>
              <span className="truncate">
                {bA ? (lang === 'en' ? bA.nameEn : bA.nameHi) : 'Structure A'}
                {bB ? ` & ${lang === 'en' ? bB.nameEn : bB.nameHi}` : ''}
              </span>
            </div>
            <div className="text-[11px] text-slate-400 truncate">
              {hasBoth
                ? lang === 'en'
                  ? 'Both structures loaded • Ready to view'
                  : 'दोनों इमारतें चुनी गईं • तुलना देखें'
                : lang === 'en'
                ? 'Click "Compare" on a second structure to launch'
                : 'तुलना शुरू करने के लिए दूसरी इमारत पर "तुलना" दबाएं'}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onOpenCompare}
            className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-[#B6FFED] hover:bg-[#9effe4] text-[#0a0a0a] flex items-center gap-1 transition-all shadow-[0_0_15px_rgba(182,255,237,0.3)]"
          >
            <span>{lang === 'en' ? 'Compare' : 'तुलना'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => clearCompare()}
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors"
            title="Clear compare selection"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
